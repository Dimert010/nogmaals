from RobotArm import RobotArm
robotArm = RobotArm('exercise 11')
color = robotArm.scan()

robotArm.wait()